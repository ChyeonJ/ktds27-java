package com.ktdsuniversity.edu.members.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktdsuniversity.edu.members.dao.MembersDao;
import com.ktdsuniversity.edu.members.vo.request.SignVO;
import com.ktdsuniversity.edu.members.vo.response.SearchVO;

@Service
public class MemberServiceImpl implements MemberService{

	@Autowired
	private MembersDao membersDao;

	@Override
	public boolean createRegist(SignVO signVO) {
		
		int checkCount = this.membersDao.insertRegist(signVO);
		return checkCount == 1;
	}
	
	@Override
	public SignVO findMembersByArticleId(String articleId) {
		
		SignVO result = this.membersDao.selectByArticleId(articleId);
		
		return result;
	}
	
	@Override
	public boolean updateMemberById(SignVO signVO) {
		
		int resultCount = this.membersDao.updateMember(signVO);
		
		return resultCount == 1;
	}
	
	@Override
	public boolean doDeleteMember(String id) {
		
		int resultCount = this.membersDao.deleteOne(id);
		return resultCount == 1;
	}
	
	@Override
	public SearchVO findMemberList() {
		SearchVO result = new SearchVO();
		int resultCount = this.membersDao.selectCount();
		result.setSearchCount(resultCount);
		List<SignVO> list  =  this.membersDao.selectAllMembers();
		result.setSearchList(list);
		return result;
	}
	
}
