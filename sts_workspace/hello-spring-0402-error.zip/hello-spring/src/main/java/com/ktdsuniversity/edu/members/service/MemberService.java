package com.ktdsuniversity.edu.members.service;

import com.ktdsuniversity.edu.members.vo.request.SignVO;
import com.ktdsuniversity.edu.members.vo.response.SearchVO;

public interface MemberService {

	boolean createRegist(SignVO signVO);

	SignVO findMembersByArticleId(String articleId);

	boolean updateMemberById(SignVO signVO);

	boolean doDeleteMember(String id);

	SearchVO findMemberList();

}
