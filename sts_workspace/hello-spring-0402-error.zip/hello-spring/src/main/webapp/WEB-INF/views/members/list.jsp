<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>게시글 목록</title>
    <link rel="stylesheet" type="text/css" href="/css/hello-spring.css">
  </head>
  <body>
    <div class="grid list">
      <h1>회원 목록</h1>
      <div>총 ${resultCount}명의 회원이 검색되었습니다.</div>
      <table class="grid">
        <thead>
          <tr>
            <th>이메일</th>
            <th>이름</th>
            <th>비밀번호</th>
          </tr>
        </thead>
        <tbody>
	      <c:choose>
	        <c:when test="${not empty searchMemberResult}">
	         <c:forEach items="${searchMemberResult}" var="members">
	           <tr>
	             <td>${members.email}</td>
	             <td>
	             <a href="/member/${members.email}">
	             ${members.name}</a></td>
	             <td>${members.password}</td>
	           </tr>
	         </c:forEach>
	        </c:when>
	        <c:otherwise>
	           <tr>
	             <td colspan="3">등록된 회원이 없습니다</td>
	           </tr>
	        </c:otherwise>
	      </c:choose>
        </tbody>
      </table>
      <div class="btn-group">
        <div class="right-align">
          <a href="/regist">회원 가입</a>
        </div>
      </div>
    </div>
  </body>
</html>