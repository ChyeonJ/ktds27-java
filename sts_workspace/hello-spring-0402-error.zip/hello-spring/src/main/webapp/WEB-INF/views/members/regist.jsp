<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%> <%@ taglib prefix="form"
uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>Members Regist</title>
    <script type="text/javascript" src="/js/jquery-4.0.0.slim.min.js"></script>
    <script type="text/javascript" src="/js/members.js"></script>
    <link rel="stylesheet" type="text/css" href="/css/hello-spring.css" />
  </head>
  <body>
    <h1>회원가입</h1>
    <form:form modelAttribute="signVO" method="post" action="/regist">
      <div class="grid write">
        <label for="email">이메일</label>
        <div class="div-input">
          <input
            type="email"
            id="email"
            name="email"
            placeholder="이메일을 입력하세여"
            value="${inputData.email}"
          />
          <form:errors path="email" cssClass="validation-error" element="div" />
        </div>
        <label for="name">이름</label>
        <div class="div-input">
          <input
            type="text"
            id="name"
            name="name"
            placeholder="이름을 입력하세요"
            value="${inputData.name}"
          />
          <form:errors path="name" cssClass="validation-error" element="div" />
        </div>
        <label for="password">패스워드</label>
        <div class="div-input">
          <input
            type="password"
            id="password"
            name="password"
            placeholder="패스워드를 입력하세요"
          />
          <form:errors
            path="password"
            cssClass="validation-error"
            element="div"
          />
        </div>
        <div class="btn-group">
          <div class="right-align">
            <input type="submit" value="회원가입" />
          </div>
        </div>
      </div>
    </form:form>
  </body>
</html>
