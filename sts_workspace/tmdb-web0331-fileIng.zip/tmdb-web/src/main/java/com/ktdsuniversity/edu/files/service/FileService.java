package com.ktdsuniversity.edu.files.service;

public interface FileService {

}
