package com.ktdsuniversity.edu.members.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktdsuniversity.edu.members.dao.MembersDao;
import com.ktdsuniversity.edu.members.helpers.SHA256Util;
import com.ktdsuniversity.edu.members.vo.request.LoginVO;
import com.ktdsuniversity.edu.members.vo.request.SignVO;
import com.ktdsuniversity.edu.members.vo.response.SearchVO;

import jakarta.validation.Valid;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MembersDao membersDao;

	@Override
	public SignVO findMembersByEmailAndPassword(LoginVO loginVO) {

		// 1. Email을 이용해 회원 정보 조회하기 (selectByArticleId)
		String inputEmail = loginVO.getEmail();
		SignVO resultEmailData = this.membersDao.selectByArticleId(inputEmail);

		// IllegalArgumentsException
		if (resultEmailData == null) {
			// 2. 조회된 결과가 없다면 "이메일 또는 비밀번호가 잘못되었습니다" 예외 던지기
			throw new IllegalArgumentException("이메일 또는 비밀번호가 잘못되었습니다.");
		}

		if (resultEmailData.getBlockYn().equals("Y")) {

			// 로그인 Block 된 시간으로부터 120분이 지나면 다시 로그인 가능한 상태로 변경한다.
			// 이 경우엔 예외를 던지지 않도록한다.
			String loginFailDate = resultEmailData.getLatestLoginFailDate();

			DateTimeFormatter dateTimePattern = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			LocalDateTime lastestBlockDateTime = LocalDateTime.parse(loginFailDate, dateTimePattern);
			
			// 마지막 로그인 실패 시간이 현재 시간에서 두시간 이전의 시간보다 이후라면?
			// 		14           15시   ==>  13시
			// 아직 두시간이 경과하지 않았기 때문에 
			if (lastestBlockDateTime.isAfter(LocalDateTime.now().minusHours(2))) {
				// 예외를 던짐
				// Block Y-N이 Y면 비밀번호가 맞든 틀리든 에러처리를 반환하겠다.
				throw new IllegalArgumentException("이메일 또는 비밀번호가 잘못되었습니다.");
			}
		}

		// 3. 조회된 결과가 있다면 사용자가 전송한 비밀번호와 조회된 회원의 salt를 이용해 SHA 엄호화하기
		String doSalt = resultEmailData.getSalt();
		String inputUserPassword = loginVO.getPassword();
		String selectByEmailData = resultEmailData.getPassword();

		// 암호화 진행
		inputUserPassword = SHA256Util.getEncrypt(inputUserPassword, doSalt);

		// 4. 3에서 암호화한 비밀번호와 1에서 조회한 비밀번호가 일치하는지 확인하기
		if (!inputUserPassword.equals(selectByEmailData)) {
			// 해당 이메일의 로그인 실패 횟수를 1 증가 시키고
			// 최근 로그인 실패 날짜를 현재 날짜와 시간으로 변경한다
			this.membersDao.updateIncreaseLoginFailCount(inputEmail);

			// 최근 로그인 실패 횟수가 5 이상이라면 block-yn을 Y로 변경한다.
			this.membersDao.updateBlock(inputEmail);

			// 5. 비밀번호가 일치하지 않는다면 "이메일 또는 비밀번호가 잘못되었습니다" 예외 던지기
			throw new IllegalArgumentException("이메일 또는 비밀번호가 잘못되었습니다.");
		}

		// 로그인 성공 처리
		// 1. login_fail_count를 0으로 초기화
		// 2. latest_login_ip를 현재 아이피로 변경
		// 3. login_date를 현재 시간으로 변경.
		// 4. block_yn을 'N'으로 변경
		this.membersDao.updateSuccessLogin(loginVO);

		// 6. 비밀번호가 일치하면 1에서 조회한 결과를 반환함
		return resultEmailData;
	}

	@Override
	public boolean createRegist(SignVO signVO) {

		SignVO membersVO = this.membersDao.selectByArticleId(signVO.getEmail());
		if (membersVO != null) {
			throw new IllegalArgumentException(signVO.getEmail() + "은 이미 사용중입니다.");
		}

		// 암호화를 위한 비밀키 생성
		String newSalt = SHA256Util.generateSalt();
		String usersPassword = signVO.getPassword();
		// 사용자가 입력한 비밀번호를 newSalt를 이용해 암호화
		// 비밀번호와 newSalt의 값이 일치하면, 항상 같은 값의 암호화 결과가 생성된다.
		usersPassword = SHA256Util.getEncrypt(usersPassword, newSalt);

		// 비밀키 저장
		signVO.setSalt(newSalt);
		// 암호화된 비밀번호 저장
		signVO.setPassword(usersPassword);

		int checkCount = this.membersDao.insertRegist(signVO);
		return checkCount == 1;
	}

	@Override
	public SignVO findMembersByArticleId(String articleId) {

		SignVO result = this.membersDao.selectByArticleId(articleId);

		return result;
	}

	@Override
	public boolean updateMemberById(SignVO signVO) {

		int resultCount = this.membersDao.updateMember(signVO);

		return resultCount == 1;
	}

	@Override
	public boolean doDeleteMember(String id) {

		int resultCount = this.membersDao.deleteOne(id);
		return resultCount == 1;
	}

	@Override
	public SearchVO findMemberList() {
		SearchVO result = new SearchVO();
		int resultCount = this.membersDao.selectCount();
		result.setSearchCount(resultCount);
		List<SignVO> list = this.membersDao.selectAllMembers();
		result.setSearchList(list);
		return result;
	}

}
