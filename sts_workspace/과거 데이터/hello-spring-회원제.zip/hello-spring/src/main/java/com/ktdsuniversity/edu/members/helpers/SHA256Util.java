package com.ktdsuniversity.edu.members.helpers;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

/**
 * SHA-256 암호화 유틸리티 * @author Minchang Jang
 */
public class SHA256Util {

	/**
	 * SHA-256 암호화를 수행한다. * @param source 원본 문자열
	 * 
	 * @param salt SALT 값 (String)
	 * @return 암호화된 결과 문자열
	 */
	public static String getEncrypt(String source, String salt) {
		return getEncrypt(source, salt.getBytes());
	}

	/**
	 * SHA-256 암호화를 수행한다. * @param source 원본 문자열
	 * 
	 * @param salt SALT 값 (byte[])
	 * @return 암호화된 결과 문자열
	 */
	public static String getEncrypt(String source, byte[] salt) {
		String result = "";

		byte[] a = source.getBytes();
		byte[] bytes = new byte[a.length + salt.length];

		// 원본 배열과 SALT 배열을 하나의 배열로 합치기
		System.arraycopy(a, 0, bytes, 0, a.length);
		System.arraycopy(salt, 0, bytes, a.length, salt.length);

		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(bytes);

			byte[] byteData = md.digest();
			StringBuffer sb = new StringBuffer();

			// 바이트 배열을 16진수 문자열로 변환
			for (int i = 0; i < byteData.length; i++) {
				sb.append(Integer.toString((byteData[i] & 0xFF) + 256, 16).substring(1));
			}
			result = sb.toString();

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * 8바이트 길이의 임의의 SALT 값을 생성한다. * @return 생성된 SALT 문자열 (Hex)
	 */
	public static String generateSalt() {
		Random random = new Random();
		byte[] salt = new byte[8];
		random.nextBytes(salt);

		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < salt.length; i++) {
			// byte 값을 Hex 값으로 바꾸기
			sb.append(String.format("%02x", salt[i]));
		}

		return sb.toString();
	}
}