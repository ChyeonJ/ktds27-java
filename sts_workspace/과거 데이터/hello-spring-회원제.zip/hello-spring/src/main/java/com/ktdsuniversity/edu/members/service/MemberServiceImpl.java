package com.ktdsuniversity.edu.members.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktdsuniversity.edu.members.dao.MembersDao;
import com.ktdsuniversity.edu.members.helpers.SHA256Util;
import com.ktdsuniversity.edu.members.vo.request.SignVO;
import com.ktdsuniversity.edu.members.vo.response.SearchVO;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MembersDao membersDao;

	@Override
	public boolean createRegist(SignVO signVO) {

		SignVO membersVO = this.membersDao.selectByArticleId(signVO.getEmail());
		if (membersVO != null) {
			throw new IllegalArgumentException(signVO.getEmail() + "은 이미 사용중입니다.");
		}
		
		//암호화를 위한 비밀키 생성
		String newSalt = SHA256Util.generateSalt();
		String usersPassword = signVO.getPassword();
		// 사용자가 입력한 비밀번호를 newSalt를 이용해 암호화
		// 비밀번호와 newSalt의 값이 일치하면, 항상 같은 값의 암호화 결과가 생성된다.
		usersPassword = SHA256Util.getEncrypt(usersPassword, newSalt);
		
		// 비밀키 저장
		signVO.setSalt(newSalt);
		// 암호화된 비밀번호 저장
		signVO.setPassword(usersPassword);

		int checkCount = this.membersDao.insertRegist(signVO);
		return checkCount == 1;
	}

	@Override
	public SignVO findMembersByArticleId(String articleId) {

		SignVO result = this.membersDao.selectByArticleId(articleId);

		return result;
	}

	@Override
	public boolean updateMemberById(SignVO signVO) {

		int resultCount = this.membersDao.updateMember(signVO);

		return resultCount == 1;
	}

	@Override
	public boolean doDeleteMember(String id) {

		int resultCount = this.membersDao.deleteOne(id);
		return resultCount == 1;
	}

	@Override
	public SearchVO findMemberList() {
		SearchVO result = new SearchVO();
		int resultCount = this.membersDao.selectCount();
		result.setSearchCount(resultCount);
		List<SignVO> list = this.membersDao.selectAllMembers();
		result.setSearchList(list);
		return result;
	}

}
