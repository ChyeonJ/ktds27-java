package com.ktdsuniversity.edu.board.vo.request;

import java.util.List;

/**
 * 게시글 등록을 위해 
 * 브라우저에서 컨트롤러(엔드포인트)로 전송되는
 * 파라미터를 받아오기 위한 클래스.
 * 
 * Spring이 파라미터를 WriteVO의 멤버변수로 할당할 때 
 * setter를 이용함 => setter가 없다면 파라미터가 들어오지 않음
 */
public class UpdateVO extends WriteVO{
	
	private List<Integer> deleteFileNum;

	public List<Integer> getDeleteFileNum() {
		return this.deleteFileNum;
	}

	public void setDeleteFileNum(List<Integer> deleteFileNum) {
		this.deleteFileNum = deleteFileNum;
	}

	//writeVO에 id 존재
//	private String id;
//	
//	public String getId() {
//		return this.id;
//	}
//	public void setId(String id) {
//		this.id = id;
//	}
}
