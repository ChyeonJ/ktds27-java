package com.ktdsuniversity.edu;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CalculateController {
	
	/**
	 * <pre>
	 * 엔드포인트 = /calc
	 * 반환시키는 템플릿 이름 = calc.jsp
	 * 템플릿으로 반환 시키는 데이터
	 * 		1. firstNum
	 * 		2. secondNum
	 * 		3. result(firstNum + secondNum의 결과)
	 * 템플릿의 결과
	 * <div>
	 * 	<span>firstNum의 값</span>
	 * 	<span> + secondNum의 값</span>
	 * 	<span> = result의 값</span>
	 * </div>
	 * </pre>
	 * 
	 */
	
	@GetMapping("/calc")
	public String addResult(Model model) {
		model.addAttribute("firstNum", "10");
		model.addAttribute("secondNum", "5");
		model.addAttribute("result","15");
		return "calc";
	}
	
	/**
	 * <pre>
	 * Browser에서 Endpoint로 파라미터를 보내는 3가지 방법
	 * 	1. Query String Parameter => endpoint 뒤에 "?"를 이용해 보내는 방법
	 * 		예> /endporint?key=value&ket2=value2&....
	 * 		예> /calc2?firstNum=3&second=10
	 *  2. Form Parameter => <form></form>을 이용해서 보내는 방법
	 *  	예> <form action="/endpoint">
	 *  			<input name="key" value="value"/>
	 *  			<select name="key">
	 *  				<option value="value2">Text</option>
	 *  				<option value="value3">Other</option>
	 *  			</select>
	 *  			<textarea name="key3">Value</textarea>
	 *  		</form>
	 *  3. Request Body - Http Request Body 영역에 파라미터를 보내는 방법
	 *  	예> 파일업로드, AJAX 요청할 떄 사용  
	 *  4. Hybrid (Alternative - Complex)
	 *  	=> Query String Parameter + Form Parameter
	 *  	=> Query String Parameter + Request Body
	 *  	* Spring 전용 Parameter
	 *  		=> Path(URL) Variable
	 *  			=> Query String Parameter 외의 파라미터를 URL로 보내는 방법
	 *  Spring Endpoint에서 파라미터를 받아오는 4가지 방법
	 *  	1.HttpServletRequest 객체를 이용하는 방법 (스프링에서 잘 사용되지는 않는다 . 쓰이긴 쓰임)
	 *  		=> Query String Parameter, Form Parameter, Request Body
	 *  		=> HTTP Header 정보 취득 가능. "요청자(브라우저)의 IP취득 가능 이거를 가져올 떄 쓰임"
	 *  			=> Endpoint를 호출한 위치(Referrer) 취득 가능
	 *  	2. @RequestParam을 이용하는 방법 (종종 사용됨 - 파라미터의 개수가 적을 때 - 2개이하)
	 *  		=> Query String Parameter, Form Parameter
	 *  	3. @ModelAttribute를 이용하는 방법 (이게 가장 많이 사용함 = 파라미터의 개수가 많을 때)
	 *  		=> Command Object, @ModelAttribute Annotation은 생략 가능
	 *  		=> Query String Parameter, Form Parameter라는 것을 받아 올 수 있음
	 *  	4. @RequestBody를 이용하는 방법 (API-AJAX기반의 프로젝트에서 주로 사용됨)
	 *  		=> Request Body를 취득 Request Body - Http Request Body
	 *  	5. @Pathvariable를 이용하는 방법 (가장 많이 사용됨 - Path(URL) Variable을 취득할 때 사용)
	 *</pre>
	 *  
	 */
	// /calc2?f=1&s=3
	//required => 필수 파라미터 해지
	// defaultValue => 기본 값은 0
	@GetMapping("/calc2")
	public String viewParamCalcPage(
			@RequestParam(required = false, defaultValue="0") int f,
			@RequestParam(required = false, defaultValue="0") int s,
			Model model) {
		int result = f + s;
		model.addAttribute("firstNum",f);
		model.addAttribute("secondNum",s);
		model.addAttribute("result",result);
		return "calc";
	}

}
