package com.ktdsuniversity.edu.security.authenticate.oauth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;

import com.ktdsuniversity.edu.members.dao.MembersDao;
import com.ktdsuniversity.edu.members.vo.MembersVO;
import com.ktdsuniversity.edu.members.vo.request.OAuthMemberVO;
import com.ktdsuniversity.edu.members.vo.request.RegistVO;

public class HelloSpringOAuthService 
	// OAuth를 통해 회원을 조회하는 인터페이스
	implements OAuth2UserService<OAuth2UserRequest, OAuth2User>{
	
	private final static Logger logger = LoggerFactory.getLogger(HelloSpringOAuthService.class);
	
	private MembersDao membersDao;
	
	public HelloSpringOAuthService(MembersDao membersDao) {
		this.membersDao = membersDao;
	}
	
	
	/**
	 *  /oauth2/authorization/naver or google을 통해 로그인한 이우 수행되는 메소드
	 *  naver또는 google에서 redirect-uri로 응답을 돌려줄 때 실행된다.
	 *  @param userRequest oauth 서비스 제공자(naver, google)에게 개인정보를 요청하는 객체
	 *  		1. authorization-uri 호출해서 oauth 인증 수행
	 *  		2. 인증 성공 후 token-uri 호출해서 oauth token을 발급 받는다.
	 *  		3. 발급받은 oauth token을 이용해서 user-info-uri를 호출해서 사용자 정보 취득
	 *  @return Oauth2User 서비스 세공자(naver, google)로 부터 
	 *  		 취득한 사용자의 정보를 이용해 Security 인증 정보 생성
	 */
	@Override
	public OAuth2User loadUser(OAuth2UserRequest userRequest) 
				throws OAuth2AuthenticationException {
		
		//userRequest를 통해서 개인 정보 취득하기 1~3 다 하겠다
		// OAuth2UserService의 기본 객체를 생성 후 userRequest 전달
		// 우리가 객체인데 왜? 반드시 객체를 생성해서 받아야한다?
		// Spring이 지원하는 기본 코드? naver로 부터 로그인 결과를 받았을 떄
		//, loadUser를수행하고 받고나서 userService를 실행시켜서 2,3번을 수행하겠다
		OAuth2UserService<OAuth2UserRequest, OAuth2User> userService = 
										new DefaultOAuth2UserService();
		
		OAuth2User oauthResult = userService.loadUser(userRequest);
		
		//yml에 등록한 Registration의 ID를 들고옴
		String registrationId = userRequest.getClientRegistration().getRegistrationId();
		
		// 회원 정보
		MembersVO oauthMember = null;
		OAuth2User oauth2Principal = null;
		
		if(registrationId.equals("naver")) {
			//OAuth 전용 인증 객체를 생성해서 반환
			oauthMember = new MembersVO();
			oauth2Principal = 
					new NaverOAuthUserDetails(oauthMember, oauthResult.getAttributes());
		}
		else if (registrationId.equals("google")) {
			oauthMember = new MembersVO();
			oauth2Principal =
					new GoogleOAuthUserDetails(oauthMember, oauthResult.getAttributes());
		}
		
		
		logger.debug(oauthResult.toString());
		
		// OAUTH 회원의 정보를 DB에 Insert한다.
		// 이미 존재하는 회원이라면 insert 하지 않도록 한다.
		if(oauthMember != null) {
			
			boolean isGuest = this.membersDao.selectMemberByEmail(oauthMember.getEmail())  == null;
			
			if(isGuest) {
				RegistVO registVO = new RegistVO();
				registVO.setEmail(oauthMember.getEmail());
				registVO.setName(oauthMember.getName());
				registVO.setPassword("NONE");
				registVO.setSalt("NONE");
				
				this.membersDao.insertNewMember(registVO);
			}
			
			//OAuthMember 테이블
			OAuthMemberVO oauthMemberVO = new OAuthMemberVO();
			oauthMemberVO.setEmail(oauthMember.getEmail());
			oauthMemberVO.setRegistrationId(registrationId);
			oauthMemberVO.setName(oauthMember.getName());
			
			boolean isNewOuth = this.membersDao.selectOAuthMemberByEmailAndRegistrationId(oauthMemberVO) == null;
			if(isNewOuth) {
				this.membersDao.insertNewOAuthMember(oauthMemberVO);
			}
		}
		return oauth2Principal;
	}
}
