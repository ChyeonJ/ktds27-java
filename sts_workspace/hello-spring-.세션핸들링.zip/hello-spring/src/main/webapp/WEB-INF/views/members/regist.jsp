<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%> <%@ taglib prefix="form"
uri="http://www.springframework.org/tags/form" %>
<jsp:include page="/WEB-INF/views/templates/header.jsp">
    <jsp:param value="회원가입" name="title" />
    <jsp:param
        value="<script type='text/javascript' src='/js/members.js'></script>"
        name="scripts" />
</jsp:include>
    <h1>회원가입</h1>
    <form:form modelAttribute="signVO" method="post" action="/regist">
      <div class="grid write">
        <label for="email">이메일</label>
        <div class="input-div">
          <input
            type="email"
            id="email"
            name="email"
            placeholder="이메일을 입력하세여"
            value="${inputData.email}"
          />
          <form:errors path="email" cssClass="validation-error" element="div" />
        </div>
        <label for="name">이름</label>
        <div class="input-div">
          <input
            type="text"
            id="name"
            name="name"
            placeholder="이름을 입력하세요"
            value="${inputData.name}"
          />
          <form:errors path="name" cssClass="validation-error" element="div" />
        </div>

        <label for="password">패스워드</label>
        <div class="input-div">
          <input
            type="password"
            id="password"
            name="password"
            placeholder="패스워드를 입력하세요"
          />
          <form:errors
            path="password"
            cssClass="validation-error"
            element="div"
          />
        </div>

        <!-- 비밀번호 두 번 입력하기 ==> 두 비밀번호가 일치할 때만 회원가입 시키기. -->
        <label for="confirm-password">비밀번호 확인</label>
        <div class="input-div">
          <input
            type="password"
            id="confirm-password"
            name="confirm-password"
            placeholder="비밀번호를 입력하세요"
          />
        </div>

        <!-- 비밀번호 한 번 입력하기 ==> 비밀번호를 확인하는 기능 -->
        <label for="show-password">비밀번호 확인하기</label>
        <div class="input-div">
          <input type="checkbox" id="show-password" />
        </div>

        <div class="btn-group">
          <div class="right-align">
            <input type="submit" value="회원가입" />
          </div>
        </div>
      </div>
    </form:form>
<jsp:include page="/WEB-INF/views/templates/footer.jsp"></jsp:include>
